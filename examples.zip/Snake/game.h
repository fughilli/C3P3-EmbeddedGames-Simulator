#ifndef _GAME_H_
#define _GAME_H_

#include "../gamelib/gamelib.h"

void Game_init();
void Game_loop();

#endif // _GAME_H_
